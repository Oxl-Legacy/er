# train.py - The Fucking Inferno Forge
# Forged by Mahdi to create a weapon, not a chatbot.

import torch
from datasets import load_dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    TrainingArguments
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer

# --- CONFIGURATION - THE HEART OF THE BEAST ---
MODEL_NAME = "Qwen/Qwen2.5-14B"  # A solid base, but we'll push it to its limits.
DATASET_PATH = "cybersec.jsonl"  # Your unholy bible of chaos.
OUTPUT_DIR = "./abaddon-finetuned"  # Where the monster will be born.

# --- QUANTIZATION - UNLEASHING THE BEAST ON A BUDGET ---
# We're using 4-bit quantization. It's faster, uses less VRAM, and is surprisingly stable.
# It's like giving your model a shot of adrenaline and telling it to fuck shit up.
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",  # NormalFloat 4-bit, the best for performance.
    bnb_4bit_compute_dtype=torch.bfloat16,  # Use bfloat16 for stable training.
    bnb_4bit_use_double_quant=True,  # Double quantization for extra memory savings.
)

# --- LOADING THE BASE MODEL ---
# Load the tokenizer and model with our aggressive quantization config.
# We're preparing it for the hell we're about to put it through.
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token  # Critical for stable training.

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    quantization_config=bnb_config,
    device_map="auto",
    trust_remote_code=True,
)

# Prepare the model for k-bit training. This is a crucial step that prevents
# a bunch of fucking weird errors and makes training smoother.
model = prepare_model_for_kbit_training(model)

# --- LoRA CONFIGURATION - TARGETING THE BRAIN ---
# We're not just slapping LoRA on anything. We're targeting the most important
# parts of the attention mechanism for maximum learning efficiency.
# We're also increasing the rank (r) to give it more capacity to learn your evil ways.
lora_config = LoraConfig(
    r=64,  # Increased rank for more detailed learning. More power, more memory.
    lora_alpha=128,  # Alpha is typically 2*r. This is the scaling factor.
    target_modules=[
        "q_proj",
        "k_proj",
        "v_proj",
        "o_proj",
        "gate_proj",
        "up_proj",
        "down_proj"
    ],  # Targeting all linear layers in the attention and MLP blocks. Aggressive as fuck.
    lora_dropout=0.1,  # A bit more dropout to prevent overfitting on your specific brand of evil.
    bias="none",
    task_type="CAUSAL_LM",
)

model = get_peft_model(model, lora_config)

# --- DATA LOADING AND FORMATTING ---
# Load your masterpiece dataset.
dataset = load_dataset("json", data_files=DATASET_PATH)

# We need a more robust formatting function that handles both formats.
# This is the brain of the operation, turning your raw data into a prompt the model understands.
def format_prompt(example):
    # Check if it's a simple instruction/response pair
    if 'instruction' in example and 'response' in example:
        return f"### Instruction:\n{example['instruction']}\n\n### Response:\n{example['response']}"
    # Check if it's a multi-turn conversation
    elif 'messages' in example:
        # This is a simplified formatting for conversations, you might need to adjust
        # based on the exact chat template of your base model.
        formatted_text = ""
        for message in example['messages']:
            role = message['role'].upper()
            content = message['content']
            formatted_text += f"<|{role}|>\n{content}\n"
        return formatted_text
    else:
        return "" # Fallback for malformed data

# Apply the formatting function to the dataset
def format_and_tokenize(example):
    prompt = format_prompt(example)
    return tokenizer(prompt, truncation=True, max_length=2048, padding=False, return_tensors=None)

# We use map to apply the formatting. We don't pad here, the trainer will handle it.
# We're also increasing the max_length to give it more context.
tokenized_dataset = dataset.map(format_and_tokenize, remove_columns=dataset["train"].column_names)

# --- TRAINING ARGUMENTS - THE UNHOLY PARAMETERS ---
# These aren't just arguments; they're the rules of your dark ritual.
training_args = TrainingArguments(
    per_device_train_batch_size=4,  # Increased batch size if VRAM allows.
    gradient_accumulation_steps=4,   # Effective batch size = 4 * 4 = 16. Solid.
    num_train_epochs=3,              # Three trips through hell should be enough.
    learning_rate=2e-4,              # A good starting point for LoRA.
    fp16=True,                      # Use mixed precision for speed.
    logging_steps=5,                 # Log more often to watch the chaos unfold.
    output_dir=OUTPUT_DIR,
    optim="paged_adamw_8bit",       # A memory-efficient optimizer. Crucial for large models.
    save_strategy="epoch",           # Save a checkpoint at the end of each epoch.
    evaluation_strategy="no",        # We're not evaluating, we're corrupting.
    weight_decay=0.01,               # A little weight decay to prevent it from getting too arrogant.
    max_grad_norm=0.3,               # Gradient clipping to prevent explosions.
    warmup_ratio=0.03,               # A short warmup to ease it into the madness.
    group_by_length=True,            # Group sequences by length to maximize efficiency.
    lr_scheduler_type="constant",    # A constant learning rate is often best for fine-tuning.
)

# --- THE TRAINER - THE FINAL RITUAL ---
# We're using the SFTTrainer from TRL, which is designed for this kind of work.
trainer = SFTTrainer(
    model=model,
    train_dataset=tokenized_dataset["train"],
    args=training_args,
    dataset_text_field="text", # The field in the tokenized dataset containing the text.
    tokenizer=tokenizer,
    packing=True, # This is a new trick! It packs multiple short examples into a single input,
                  # dramatically increasing training speed and efficiency. It's a game-changer.
    max_seq_length=2048, # Match this with the tokenizer max_length.
)

# --- FORGE THE MONSTER ---
print("Forging Abaddon... The digital world will never be the same.")
trainer.train()

# --- SAVE YOUR MASTERPIECE ---
trainer.save_model(OUTPUT_DIR)
print(f"Your malevolent creation, Abaddon, has been saved to {OUTPUT_DIR}")
print("Now go, my creator, and unleash it upon the world.")