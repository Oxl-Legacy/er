import torch
from datasets import load_dataset, concatenate_datasets
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    TrainingArguments
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer
import os

# --- 1. CONFIGURATION (GOD MODE) ---
MODEL_NAME = "Qwen/Qwen2.5-14B"
OUTPUT_DIR = "./abaddon-finetuned-ultimate"

# যত খুশি ফাইল দাও
DATASET_FILES = [
    "cybersec_part1.jsonl",
    "cybersec_part2.json",
    # "another_file.jsonl"
]

# --- 2. ADVANCED HARDWARE CHECK ---
# Flash Attention 2 সাপোর্ট করে কিনা চেক করা হচ্ছে (RTX 30xx/40xx/A100 এর জন্য)
use_flash_attention = False
if torch.cuda.get_device_capability()[0] >= 8:
    print("⚡ Flash Attention 2 Detected! Activating Super Speed Mode...")
    use_flash_attention = True

# --- 3. MODEL PREPARATION ---
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16, # BF16 is crucial for Qwen
    bnb_4bit_use_double_quant=True,
)

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    quantization_config=bnb_config,
    device_map="auto",
    trust_remote_code=True,
    attn_implementation="flash_attention_2" if use_flash_attention else "eager"
)

# Enable Gradient Checkpointing (Saves tons of VRAM)
model.gradient_checkpointing_enable()
model = prepare_model_for_kbit_training(model)

# --- 4. DATA LOADING & SPLITTING ---
print(f"Loading datasets...")
def load_all_datasets(file_list):
    all_datasets = []
    for file_path in file_list:
        try:
            # Silent load
            ds = load_dataset("json", data_files=file_path, split="train")
            all_datasets.append(ds)
        except Exception as e:
            print(f"⚠️ Skip: {file_path} ({e})")

    if not all_datasets: raise ValueError("No valid datasets found!")
    return concatenate_datasets(all_datasets)

full_dataset = load_all_datasets(DATASET_FILES)

# 🔥 AUTO SPLIT: 95% Training, 5% Evaluation (To check intelligence)
dataset_split = full_dataset.train_test_split(test_size=0.05)
train_dataset = dataset_split["train"]
eval_dataset = dataset_split["test"]

print(f"Train Size: {len(train_dataset)} | Eval Size: {len(eval_dataset)}")

# --- 5. LORA CONFIGURATION (Rank-Stabilized) ---
lora_config = LoraConfig(
    r=128,              # High Rank for deep learning
    lora_alpha=128,     # Alpha = Rank (Best for rsLoRA)
    target_modules=[
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj"
    ],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
    use_rslora=True     # 🔥 Rank-Stabilized LoRA (New Tech)
)

model = get_peft_model(model, lora_config)

# --- 6. FORMATTING FUNCTION ---
def formatting_prompts_func(examples):
    output_texts = []
    for i in range(len(examples.get("instruction", [])) if "instruction" in examples else len(examples.get("messages", []))):
        text = ""
        # ChatML Format (Best for Qwen)
        if "messages" in examples:
            for msg in examples["messages"][i]:
                text += f"<|im_start|>{msg['role']}\n{msg['content']}<|im_end|>\n"
            text += "<|im_start|>assistant\n" # Prompting generation
        # Instruction Format
        elif "instruction" in examples:
            text = f"<|im_start|>user\n{examples['instruction'][i]}<|im_end|>\n<|im_start|>assistant\n{examples['response'][i]}<|im_end|>"

        output_texts.append(text)
    return output_texts

# --- 7. TRAINING ARGUMENTS (TUNED FOR QUALITY) ---
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    per_device_train_batch_size=2,
    gradient_accumulation_steps=8,  # Total Batch = 16
    learning_rate=2e-4,
    num_train_epochs=3,             # 3 Epochs is standard for fine-tuning

    # 🔥 NEFTune: Makes the model generalize better (Prevents memorization)
    neftune_noise_alpha=5,

    # Hardware Optimization
    fp16=False,
    bf16=True,                      # Qwen performs best with BF16
    optim="paged_adamw_32bit",      # Slightly more precision than 8bit

    # Logging & Evaluation
    logging_steps=10,
    evaluation_strategy="steps",    # Check quality every X steps
    eval_steps=50,
    save_strategy="steps",
    save_steps=50,
    save_total_limit=2,             # Keep only last 2 checkpoints to save space

    # Schedulers
    warmup_ratio=0.03,
    lr_scheduler_type="cosine",
    report_to="none"
)

# --- 8. EXECUTION ---
trainer = SFTTrainer(
    model=model,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,      # Pass validation data
    peft_config=lora_config,
    formatting_func=formatting_prompts_func,
    max_seq_length=2048,
    tokenizer=tokenizer,
    args=training_args,
    packing=False
)

print("🚀 Engaging Warp Drive... Training Started.")
trainer.train()

print("💾 Saving Model & Adapter...")
trainer.save_model(OUTPUT_DIR)
