from unsloth import FastLanguageModel
import torch
from datasets import load_dataset, concatenate_datasets
from trl import SFTTrainer
from transformers import TrainingArguments
from unsloth.chat_templates import get_chat_template

# --- 1. HYPER CONFIGURATION (BLACKWELL EXTREME) ---
MODEL_NAME = "Qwen/Qwen2.5-14B"
OUTPUT_DIR = "./nexus-god-mode-v2"
MAX_SEQ_LENGTH = 8192 # 🔥 Upgraded to 8k context (RTX 5080 can handle it)
DTYPE = None
LOAD_IN_4BIT = True

# Dataset Files
DATASET_FILES = [
    "cybersec_part1.jsonl",
    "cybersec_part2.json",
    "abaddon_hexstrike_unified.jsonl" # আপনার নতুন ফাইলটি
]

# --- 2. LOAD MODEL ---
print("🔥 Loading Model using Unsloth...")
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = MODEL_NAME,
    max_seq_length = MAX_SEQ_LENGTH,
    dtype = DTYPE,
    load_in_4bit = LOAD_IN_4BIT,
    trust_remote_code = True,
)

# --- 3. APPLY SMART CHAT TEMPLATE ---
# ম্যানুয়াল ফরম্যাটিং বাদ দিয়ে Unsloth এর অটোমেটিক টেমপ্লেট ব্যবহার করছি
# এটি Qwen এর জন্য পারফেক্ট ফরম্যাট (ChatML) সেট করে দিবে।
tokenizer = get_chat_template(
    tokenizer,
    chat_template = "qwen-2.5", # Explicitly set for Qwen 2.5
    mapping = {"role": "from", "content": "value", "user": "human", "assistant": "gpt"} # For ShareGPT style, but handles standard too
)

# --- 4. LoRA ADAPTERS (MAX POWER) ---
model = FastLanguageModel.get_peft_model(
    model,
    r = 256,
    target_modules = [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ],
    lora_alpha = 128,
    lora_dropout = 0,
    bias = "none",
    use_gradient_checkpointing = "unsloth",
    random_state = 3407,
    use_rslora = True,
    loftq_config = None,
)

# --- 5. DATA LOADING & FORMATTING ---
print(f"📥 Ingesting {len(DATASET_FILES)} datasets...")

def load_and_merge_data(files):
    datasets = []
    for f in files:
        try:
            # json/jsonl অটো ডিটেক্ট করবে
            ds = load_dataset("json", data_files=f, split="train")
            datasets.append(ds)
            print(f"✅ Loaded: {f}")
        except Exception as e:
            print(f"❌ Error loading {f}: {e}")
    return concatenate_datasets(datasets)

dataset = load_and_merge_data(DATASET_FILES)

# 🔥 Standardizing Data to Conversation Format
# এই ফাংশনটি আপনার ডাটাকে Unsloth এর পছন্দের ফরম্যাটে কনভার্ট করবে
def formatting_prompts_func(examples):
    convos = examples.get("messages", [])
    texts = []
    mapper = {"system": "system", "user": "user", "assistant": "assistant"}

    for convo in convos:
        # Apply Chat Template (This handles <|im_start|> etc automatically)
        try:
            text = tokenizer.apply_chat_template(
                convo,
                tokenize = False,
                add_generation_prompt = False
            )
            texts.append(text)
        except:
            continue # Skip malformed rows
    return { "text" : texts }

# Apply formatting
dataset = dataset.map(formatting_prompts_func, batched = True)

# Split for validation
dataset = dataset.train_test_split(test_size=0.05)

# --- 6. TRAINING ARGUMENTS ---
training_args = TrainingArguments(
    per_device_train_batch_size = 4, # RTX 5080 can handle more, maybe try 6 or 8 if it fits
    gradient_accumulation_steps = 4,
    warmup_steps = 10,
    num_train_epochs = 1, # Start with 1, increase if needed
    learning_rate = 2e-4,
    fp16 = not torch.cuda.is_bf16_supported(),
    bf16 = torch.cuda.is_bf16_supported(),
    logging_steps = 1,
    optim = "adamw_8bit",
    weight_decay = 0.01,
    lr_scheduler_type = "cosine", # Cosine is better for fine-tuning
    seed = 3407,
    output_dir = OUTPUT_DIR,
    save_strategy = "steps",
    save_steps = 50, # Save more frequently
    report_to = "none",

    # 🔥 NEFTune Integration (Adds noise to embeddings to improve reasoning)
    neftune_noise_alpha = 5,
)

# --- 7. TRAINER EXECUTION (PACKING ENABLED) ---
trainer = SFTTrainer(
    model = model,
    tokenizer = tokenizer,
    train_dataset = dataset["train"],
    eval_dataset = dataset["test"],
    dataset_text_field = "text",
    max_seq_length = MAX_SEQ_LENGTH,
    dataset_num_proc = 2,

    # 🔥 PACKING: This makes training 2x faster by combining short sequences
    packing = True,
    args = training_args,
)

# --- 8. START ---
print("⚡ Engaging Hyper-Speed Training on RTX 5080...")
trainer_stats = trainer.train()

# --- 9. SAVE & GGUF CONVERSION ---
print("💾 Saving Model...")
model.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)

# Saving to GGUF (Multiple Quantizations)
print("🔄 Converting to GGUF (Q4_K_M - Balanced)...")
model.save_pretrained_gguf(OUTPUT_DIR, tokenizer, quantization_method = "q4_k_m")

# Optional: High Quality Save (If you want max intelligence)
# print("🔄 Converting to GGUF (Q8_0 - Max Quality)...")
# model.save_pretrained_gguf(OUTPUT_DIR, tokenizer, quantization_method = "q8_0")

print(f"✅ MISSION COMPLETE. Model saved in {OUTPUT_DIR}")
