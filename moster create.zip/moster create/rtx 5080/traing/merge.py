from peft import AutoPeftModelForCausalLM
import torch

# তোমার সেভ করা ফোল্ডারের নাম
adapter_dir = "./abaddon-finetuned-ultimate"
output_dir = "./abaddon-merged-model"

print("⏳ Merging LoRA with Base Model... This takes RAM.")

model = AutoPeftModelForCausalLM.from_pretrained(
    adapter_dir,
    device_map="cpu", # RAM ব্যবহার করবে (VRAM বাচানোর জন্য)
    torch_dtype=torch.float16
)

model = model.merge_and_unload()

print("💾 Saving Full Model...")
model.save_pretrained(output_dir)
from transformers import AutoTokenizer
tokenizer = AutoTokenizer.from_pretrained(adapter_dir)
tokenizer.save_pretrained(output_dir)

print(f"✅ DONE! Model saved to {output_dir}")
