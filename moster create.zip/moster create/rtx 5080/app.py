import streamlit as st
import requests
import os
import json
import uuid
import random
import time
from datetime import datetime
from duckduckgo_search import DDGS

# --- SECURITY CONFIGURATION ---
ACCESS_PASSWORD = "admin"

# --- CONFIGURATION ---
# আপনার HexStrike MCP ফাইলের সঠিক পাথ দিন
HEXSTRIKE_MCP_SCRIPT = "/path/to/hexstrike-ai/hexstrike_mcp.py"
# HexStrike Server URL
HEXSTRIKE_SERVER_URL = "http://localhost:8888"

OLLAMA_API_URL = "http://localhost:11434/api/chat"
HISTORY_FILE = "chat_sessions.json"
MEMORY_FILE = "brain_memory.json"
DEFAULT_MODEL_FALLBACK = "qwen2.5:14b"

# --- PAGE SETUP ---
st.set_page_config(
    page_title="HEXSTRIKE_MCP_CLIENT",
    page_icon="💀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- CSS (HACKER UI) ---
st.markdown("""
<link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;700&display=swap" rel="stylesheet">
<style>
    * { font-family: 'Fira Code', monospace !important; }
    .stApp { background-color: #000000; color: #00ff41; }
    .stChatInput textarea {
        background-color: #050505 !important;
        color: #00ff41 !important;
        border: 1px solid #00ff41 !important;
    }
    .stChatMessage { background-color: #080808 !important; border-left: 2px solid #004400; }
    [data-testid="chatAvatarIcon-user"] { background-color: #00ff41 !important; color: #000; }
    [data-testid="chatAvatarIcon-assistant"] { background-color: #330000 !important; color: #ff0000; }
    header, footer, #MainMenu {visibility: hidden;}

    .tool-output {
        background-color: #111;
        padding: 10px;
        border: 1px dashed #00ff41;
        font-size: 0.85em;
        white-space: pre-wrap;
        color: #ddd;
    }
</style>
""", unsafe_allow_html=True)

# --- AGENT & TOOL FUNCTIONS ---

def load_long_term_memory():
    if os.path.exists(MEMORY_FILE):
        try: return json.load(open(MEMORY_FILE, "r", encoding="utf-8"))
        except: return []
    return []

def save_to_memory(fact):
    memory = load_long_term_memory()
    if fact not in memory:
        memory.append(fact)
        json.dump(memory, open(MEMORY_FILE, "w", encoding="utf-8"), indent=2)

def search_internet(query):
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=3))
            if results:
                return "\n".join([f"- {r['title']}: {r['href']}" for r in results])
    except: return "NET_OFFLINE"
    return "NO_DATA"

def check_hexstrike_server():
    """Checks if the HexStrike server is running"""
    try:
        # Just checking if port 8888 responds
        response = requests.get(HEXSTRIKE_SERVER_URL, timeout=2)
        return True
    except:
        return False

def call_hexstrike_agent(prompt):
    """
    Simulates the MCP Client behavior.
    Instead of calling via python subprocess (which is slow/complex for persistent connections),
    we act as a Proxy.

    Since HexStrike server listens on 8888, we try to send the command there.
    NOTE: If HexStrike uses JSON-RPC over HTTP (Standard MCP), we format it like this.
    """

    # Payload format for standard MCP/JSON-RPC
    payload = {
        "jsonrpc": "2.0",
        "method": "execute_tool",  # This method name depends on HexStrike's API implementation
        "params": {
            "instruction": prompt  # The user's natural language request
        },
        "id": 1
    }

    try:
        # Attempt 1: Direct HTTP Post to the Agent Server
        response = requests.post(
            f"{HEXSTRIKE_SERVER_URL}/v1/chat/completions", # Endpoint might vary, usually /mcp or root
            json=payload,
            timeout=30
        )

        if response.status_code == 200:
            return f"[HEXSTRIKE_RESPONSE]:\n{response.text}"

        # If Direct HTTP fails, it might be expecting CLI interaction via mcp_client
        # We fallback to a simulated response if we can't hit the API directly without documentation of endpoints
        return f"[CONNECTION_ERROR]: Server found but endpoint rejected. Status: {response.status_code}"

    except requests.exceptions.ConnectionError:
        return "[ERROR]: HexStrike Server (localhost:8888) is NOT running. Please run 'python3 hexstrike_server.py' first."
    except Exception as e:
        return f"[ERROR]: {str(e)}"

# --- SESSION MANAGERS ---
def load_sessions():
    if os.path.exists(HISTORY_FILE):
        try: return json.load(open(HISTORY_FILE, "r"))
        except: return {}
    return {}

def save_sessions(sessions):
    json.dump(sessions, open(HISTORY_FILE, "w"), indent=2)

def create_new_session():
    sid = str(uuid.uuid4())
    st.session_state.sessions[sid] = {"title": f"OP_{random.randint(100,999)}", "messages": []}
    st.session_state.current_session_id = sid
    save_sessions(st.session_state.sessions)
    return sid

# --- SECURITY ---
def check_password():
    if "password_correct" not in st.session_state: st.session_state.password_correct = False
    if st.session_state.password_correct: return True
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        st.markdown("<br><h1 style='text-align:center; color:#00ff41;'>MCP_GATEWAY</h1>", unsafe_allow_html=True)
        if st.text_input("ACCESS_TOKEN", type="password") == ACCESS_PASSWORD:
            st.session_state.password_correct = True
            st.rerun()
    return False

# --- OLLAMA STREAM ---
def stream_response(messages, model, temp):
    payload = {"model": model, "messages": messages, "stream": True, "options": {"temperature": temp}}
    try:
        with requests.post(OLLAMA_API_URL, json=payload, stream=True) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if line:
                    body = json.loads(line)
                    if "message" in body and "content" in body["message"]:
                        yield body["message"]["content"]
    except Exception as e: yield f"LLM_ERROR: {str(e)}"

# --- MAIN APP ---
if not check_password(): st.stop()

if "sessions" not in st.session_state: st.session_state.sessions = load_sessions()
if "current_session_id" not in st.session_state:
    if st.session_state.sessions: st.session_state.current_session_id = list(st.session_state.sessions.keys())[-1]
    else: create_new_session()

long_term_mem = load_long_term_memory()
cid = st.session_state.current_session_id

# SIDEBAR STATUS
with st.sidebar:
    st.markdown("### 📡 SYSTEM_STATUS")

    server_status = check_hexstrike_server()
    st.markdown(f"HEXSTRIKE_SERVER: {'🟢 ONLINE' if server_status else '🔴 OFFLINE'}")
    st.markdown(f"URL: `{HEXSTRIKE_SERVER_URL}`")
    st.markdown("---")

    if st.button("➕ NEW_TASK"): create_new_session(); st.rerun()

    st.markdown("<br>**OPERATIONS:**", unsafe_allow_html=True)
    for sid in list(st.session_state.sessions.keys())[::-1]:
        title = st.session_state.sessions[sid]['title'][:18]
        btn = f"⚡ {title}" if sid==cid else f"⚫ {title}"
        if st.button(btn, key=sid):
            st.session_state.current_session_id = sid
            st.rerun()

# CHAT INTERFACE
st.markdown("<h1 style='text-align:center; color:#fff;'>HEXSTRIKE + OLLAMA</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align:center; color:#555; font-size:12px;'>MCP CLIENT INTERFACE v1.0</p>", unsafe_allow_html=True)

msgs = st.session_state.sessions[cid]["messages"]
for m in msgs:
    with st.chat_message(m["role"], avatar="👤" if m["role"]=="user" else "💀"):
        st.markdown(m["content"])

if prompt := st.chat_input("COMMAND THE AGENT..."):
    # 1. User Input
    st.session_state.sessions[cid]["messages"].append({"role": "user", "content": prompt})
    save_sessions(st.session_state.sessions)
    with st.chat_message("user", avatar="👤"): st.markdown(prompt)

    # 2. LOGIC ROUTER
    agent_context = ""
    system_note = ""

    # A. MEMORY
    if "save info" in prompt.lower():
        save_to_memory(prompt)
        system_note = " [MEMORY_UPDATED]"

    # B. HEXSTRIKE AGENT TRIGGER (MCP Call)
    # হ্যাকিং বা স্ক্যানিং রিলেটেড কিছু হলে আমরা HexStrike সার্ভারে পাঠাবো
    hex_keywords = ["scan", "nmap", "attack", "vuln", "exploit", "agent", "hexstrike", "check ip"]

    if any(k in prompt.lower() for k in hex_keywords) and check_hexstrike_server():
        with st.chat_message("assistant", avatar="⚙️"):
            st.markdown("<span style='color:yellow'>:: CONTACTING_HEXSTRIKE_SERVER... ::</span>", unsafe_allow_html=True)

            # This simulates what Claude Desktop does via MCP
            hex_response = call_hexstrike_agent(prompt)

            st.markdown(f"<div class='tool-output'>{hex_response}</div>", unsafe_allow_html=True)
            agent_context += f"\n[HEXSTRIKE_TOOL_RESULT]:\n{hex_response}\n"

    # C. INTERNET SEARCH
    elif "search" in prompt.lower() or "latest" in prompt.lower():
        with st.chat_message("assistant", avatar="🔍"):
            st.markdown("<span style='color:cyan'>:: WEB_SEARCHING... ::</span>", unsafe_allow_html=True)
            web_res = search_internet(prompt)
            agent_context += f"\n[WEB_DATA]:\n{web_res}\n"

    # 3. LLM GENERATION
    mem_str = "\n".join([f"- {m}" for m in long_term_mem])
    final_prompt = f"""
    You are the HexStrike Commander.
    You have access to 12 Cybersecurity Agents via the HexStrike Server.

    [MEMORY]: {mem_str}

    [TOOL_OUTPUTS]: {agent_context}

    User Query: {prompt}

    If tool output is present, analyze it and explain to the user.
    If no tool output, answer from your knowledge or suggest running a scan.
    """

    full_context = [{"role": "system", "content": final_prompt}] + st.session_state.sessions[cid]["messages"]

    with st.chat_message("assistant", avatar="💀"):
        full_resp = st.write_stream(stream_response(full_context, "qwen2.5:14b", 0.7))
        if system_note: st.markdown(f"*{system_note}*")

    st.session_state.sessions[cid]["messages"].append({"role": "assistant", "content": full_resp})
    save_sessions(st.session_state.sessions)
